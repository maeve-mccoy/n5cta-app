import XCTest
@testable import PMSuperButtonTests

XCTMain([
    testCase(PMSuperButtonTests.allTests),
])
